# EWB Students Database CRUD API

A student-record management backend built for the EWB Edu Tech internship assignment using Python, FastAPI, SQLite, SQLAlchemy, and Pydantic.

## Features

* Create, list, retrieve, update, and delete student records
* SQLite persistence
* Request validation through Pydantic
* Filter students by name, course, and date of birth
* Pagination with `skip` and `limit`
* Clear `404` errors for missing students
* `409` errors for duplicate email addresses
* Interactive API docs at `/docs`

## Student fields

* `student\_id`: automatically generated unique ID
* `name`: required
* `date\_of\_birth`: required, ISO format `YYYY-MM-DD`
* `email`: optional, but either email or phone must be supplied
* `phone`: optional, but either email or phone must be supplied
* `course`: optional
* `address`: optional
* `enrollment\_date`: optional

Email addresses must be unique when provided.

## Requirements

* Python 3.10 or newer
* VS Code or another code editor

## Run locally on Windows

Open this folder in VS Code, then run these commands in the terminal.

### 1\. Create and activate a virtual environment

```powershell
python -m venv .venv
.venv\\Scripts\\Activate.ps1
```

If PowerShell blocks activation, you can use Command Prompt instead:

```bat
.venv\\Scripts\\activate.bat
```

### 2\. Install dependencies

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 3\. Start the API

```bash
uvicorn main:app --reload
```

The API is available at `http://127.0.0.1:8000`. FastAPI creates `students.db` in the project directory when the application starts.

### 4\. Open the interactive API documentation

Visit `http://127.0.0.1:8000/docs`. Expand an endpoint, click **Try it out**, enter the request body or path parameters, and click **Execute**.

## Example requests

### Create a student

`POST /students`

```json
{
  "name": "Santhosh",
  "date\_of\_birth": "2005-03-02",
  "email": "santhuxoxo@gmail.com",
  "phone": "9346058526",
  "course": "Computer Science and Engineering in Artificial Intelligence and Machine Learning",
  "address": "Hyderabad",
  "enrollment\_date": "2026-08-01",
  "student\_id": 1
}
```

The response includes the generated `student\_id`.

### List students

`GET /students`

### Filter students

* `GET /students?name=Santhosh`
* `GET /students?course=`Computer Science and Engineering in Artificial Intelligence and Machine Learning`
* `GET /students?born\_after=2005-01-01`
* `GET /students?born\_before=2007-01-01`
* `GET /students?skip=0\&limit=20`

The birth-date filters use strict comparisons: `born\_after` returns dates later than the supplied date; `born\_before` returns dates earlier than the supplied date.

### Get one student

`GET /students/1`

Replace `1` with the student's actual ID.

### Replace all editable fields

`PUT /students/1`

Send all required create fields, just as in the create example.

### Update selected fields

`PATCH /students/1`

* ```json
{
  "course": "Computer Science and Engineering in Artificial Intelligence and Machine Learning - CSE(AIML)"
}
```

### Delete a student

`DELETE /students/1`

A successful delete returns HTTP `204 No Content`.

## Important HTTP status codes

* `201 Created`: student created
* `200 OK`: successful read or update
* `204 No Content`: student deleted
* `400 Bad Request`: empty PATCH request
* `404 Not Found`: student ID does not exist
* `409 Conflict`: duplicate email address
* `422 Unprocessable Entity`: invalid request data

## Project structure

```text
student-crud-api/
├── main.py
├── database.py
├── models.py
├── schemas.py
├── requirements.txt
├── README.md
└── .gitignore
```

`students.db` is created at runtime and intentionally excluded from Git.

## Publish to GitHub

Create an empty GitHub repository, then run from this project directory:

```bash
git init
git add .
git commit -m "Build student CRUD API"
git branch -M main
git remote add origin YOUR\_GITHUB\_REPOSITORY\_URL
git push -u origin main
```

Replace `YOUR\_GITHUB\_REPOSITORY\_URL` with the URL of your own repository. Do not commit real student information, passwords, or secrets.

## Optional future extension

After the CRUD requirements work, an optional local Ollama integration can answer natural-language questions. The model should only receive relevant data retrieved by backend code; it must not execute unrestricted SQL.

